class _2types {
    //2. Создать переменные всех пройденных типов данных, и инициализировать их значения;
    public static void main(String[] args) {
        byte b=10;
        short s = 2404;
        int i = 123456;
        long l = 1500L;
        float f = 120.0f;
        double d = 15.72775;
        boolean bool = true;
        char c = 'A';

        System.out.println(b);
        System.out.println(s);
        System.out.println(i);
        System.out.println(l);
        System.out.println(f);
        System.out.println(d);
        System.out.println(bool);
        System.out.println(c);
    }
}
