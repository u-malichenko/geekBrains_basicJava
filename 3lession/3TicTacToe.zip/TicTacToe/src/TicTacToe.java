import java.util.Scanner;
import java.util.Random;

public class TicTacToe {

    private static char[][] map;
    private static int SIZE = 3;
    private static final char DOT_EMPTY = '॰';
    private static final char DOT_X = 'X';
    private static final char DOT_O = 'O';
    private static final boolean SILLY_MODE = false;
    private static Scanner scanner = new Scanner(System.in);
    private static Random random = new Random();

    public static void main(String[] args) {
        initMap();
        printMap();

        int computerTurnCount = 0;
        while(true) {
            humanTurn();
            if (isEndGame(DOT_X)) break;

            computerTurn(computerTurnCount++);
            if(isEndGame(DOT_O)) break;
        }

        System.out.println("Игра окончена!");
    }

    private static void initMap() {
        map = new char[SIZE][SIZE];
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                map[i][j] = DOT_EMPTY;
            }
        }
    }

    private static void printMap() {
        for (int i = 0; i <= SIZE; i++) {
            for (int j = 0; j <= SIZE; j++) {
                if (i == 0) {
                    System.out.print(j + " ");
                } else if (j == 0 && i != 0) {
                    System.out.print(i + " ");
                } else {
                    System.out.print(map[i - 1][j - 1] + " ");
                }
            }
            System.out.println();
        }
    }

    private static void humanTurn() {
        int x, y;
        do {
            System.out.println("Введите координаты ячейки через пробел");
            y = scanner.nextInt() - 1;
            x = scanner.nextInt() - 1;
        } while(!isCellValid(x, y));

        map[y][x] = DOT_X;
    }

    private static void computerTurn(int turn) {
        int x = -1;
        int y = -1;
        if (SILLY_MODE || turn == 0) {
            do {
                x = random.nextInt(SIZE);
                y = random.nextInt(SIZE);
            } while (!isCellValid(x, y));
        } else {
            int positionWeight = 0, maxWeight = positionWeight;
            for (int i = 0; i < SIZE; i++) {
                for (int j = 0; j < SIZE; j++) {
                    if (isCellValid(i, j)) {
                        positionWeight = getPositionWeight(i, j);
                        if (maxWeight < positionWeight) {
                            x = i;
                            y = j;
                            maxWeight = positionWeight;
                        }
                    }
                }
            }
        }
        System.out.println("Компьютер выбрал ячейку " +  (y + 1) + " " + (x + 1));
        map[y][x] = DOT_O;
    }

    private static int getPositionWeight(int x, int y) {
        int weight = 0;
        for (int i = -1; i < 2; i++) {
            for (int j = -1; j < 2; j++) {
                // Наращиваем вес валидной ячейки, если она нужного типа
                if (x + i >= 0 && y + j >= 0 && x + i < SIZE && y + j < SIZE && map[x + i][y + j] == DOT_O) {
                    weight++;
                }
            }
        }
        return weight;
    }

    private static boolean isEndGame(char playerSymbol) {
        boolean result = false, win = false;
        printMap();
        if (checkWin(playerSymbol)) {
            System.out.println("Победили " + playerSymbol);
            result = true;
            win = true;
        }

        // Если заполнивший все поле ход победный, то ничья не выводится
        if (isMapFull() && !win) {
            System.out.println("Ничья!");
            result = true;
        }
        return result;
    }

    private static boolean isCellValid(int x, int y) {
        boolean result = true;
        if (x < 0 || x >= SIZE || y < 0 || y >= SIZE) result = false;
        if (map[y][x] != DOT_EMPTY) result = false;
        return result;
    }

    private static boolean isMapFull() {
        boolean result = true;
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (map[i][j] == DOT_EMPTY) result = false;
            }
        }
        return result;
    }

    private static boolean checkWin(char playerSymbol) {
        boolean result = false;
        if (checkRowWin(playerSymbol) || checkDiagonalWin(playerSymbol)) result = true;
        return result;
    }

    // Проверка диагоналей на победную ситуацию
    public static boolean checkDiagonalWin(char playerSymbol) {
        boolean result = false;
        int countDiagLeft = 0, countDiagRight = 0;
        for (int i = 0; i < SIZE; i++) {
            if (map[i][i] == playerSymbol) countDiagLeft++;
            if (map[i][SIZE - (i + 1)] == playerSymbol) countDiagRight++;
        }
        if (countDiagLeft == SIZE || countDiagRight == SIZE) result = true;
        return result;
    }

    // Проверка рядов и колонок на победную ситуацию
    private static boolean checkRowWin(char playerSymbol) {
        boolean result = false;
        for (int i = 0; i < SIZE; i++) {
            int countHorizontalRow = 0, countVerticalRow = 0;
            for (int j = 0; j < SIZE; j++) {
                if (map[i][j] == playerSymbol) countHorizontalRow++;
                if (map[j][i] == playerSymbol) countVerticalRow++;
            }
            if (countHorizontalRow == SIZE || countVerticalRow == SIZE) {
                result = true;
                break;
            }
        }
        return result;
    }
}
