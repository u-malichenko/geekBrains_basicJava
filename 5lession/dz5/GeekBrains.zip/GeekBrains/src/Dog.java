public class Dog extends Animal implements Swimmable {
    private final int maxLengthRun = 500;
    private final int maxLengthJump = 5;
    private final int maxLengthSwim = 10;

    @Override
    public void jump(int height) {
        System.out.print(this.getClass().getCanonicalName());
        super.jump(height);
        if(height <= maxLengthJump)
            System.out.println("true");
        else
            System.out.println("false");
    }

    @Override
    public void run(int length) {
        System.out.print(this.getClass().getCanonicalName());
        super.run(length);
        if(length <= maxLengthRun)
            System.out.println("true");
        else
            System.out.println("false");
    }

    @Override
    public void swim(int lengthSwim) {
        System.out.print(this.getClass().getCanonicalName());
        System.out.print(" swim: ");
        if(lengthSwim <= maxLengthSwim)
            System.out.println("true");
        else
            System.out.println("false");
    }
}
