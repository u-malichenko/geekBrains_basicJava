public class Employee {
    //ФИО, должность, email, телефон, зарплата, возраст;
    private String name;
    private String position;
    private String phone;
    private long salary;
    private int age;

    public Employee(String name, String position, String phone, long salary, int age) {
        this.name = name;
        this.position = position;
        this.phone = phone;
        this.salary = salary;
        this.age = age;
    }

    public int getAge() {
        return age;
    }


    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", position='" + position + '\'' +
                ", phone='" + phone + '\'' +
                ", salary=" + salary +
                ", age=" + age +
                '}';
    }
}
