public class Animal {
    //6. Животные могут выполнять действия: бежать, плыть, перепрыгивать препятствие.
    // В качестве параметра каждому методу передается величина, означающая или длину препятствия (для бега и плавания), или высоту (для прыжков);

    public void jump(int height){
        System.out.print(" jump: " + height + " ");
    }

    public void run(int length){
        System.out.print(" run: " + length + " ");
    }

    public void eat(Bowl bowl){
        System.out.print(" ест " + bowl.getTypeOfFeed() + ". ");
        System.out.print("Было еды = " + bowl.getVolume() + ". ");

    }


}
