public class Cat extends Animal {
    private String name;
    private final int maxLengthRun = 200;
    private final int maxLengthJump = 2;
    private int appetite;
    boolean isFull = false;

    public Cat(){
        this.name = "Пушок";
    }

    public Cat(String name){
        this.name = name;
    }

    public Cat(int appetite) {
        this();
        this.appetite = appetite;
    }

    public Cat(String name, int appetite) {
        this(name);
        this.appetite = appetite;
    }

    @Override
    public void jump(int height) {
        System.out.print(this.getClass().getCanonicalName());
        super.jump(height);
        if(height <= maxLengthJump)
            System.out.println("true");
        else
            System.out.println("false");
    }

    @Override
    public void run(int length) {
        System.out.print(this.getClass().getCanonicalName());
        super.run(length);
        if(length <= maxLengthRun)
            System.out.println("true");
        else
            System.out.println("false");
    }

    @Override
    public void eat(Bowl bowl) {
        System.out.print(getFullName());
        if(!this.isFull){
            if(bowl.getVolume() >= appetite){
                super.eat(bowl);
                bowl.changeVolume(-appetite);
                this.isFull = true;
            } else{
                System.out.println(" есть не стал. " + bowl.getVolume() + " слишком мало для еды. " + this.name + " остался голодным.");
            }
        } else System.out.println(" сытый.");
    }

    public String getFullName(){
        return this.name + "(lvl прожорливости = " + this.appetite + ")";
    }
}
