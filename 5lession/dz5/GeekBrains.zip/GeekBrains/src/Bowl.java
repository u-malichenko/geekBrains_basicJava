import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

public class Bowl {
    private int volume;
    private String typeOfFeed;

    public Bowl(int volume, String typeOfFeed) {
        this.volume = volume;
        this.typeOfFeed = typeOfFeed;
    }

    public int getVolume() {
        return volume;
    }

    public void changeVolume(int delta){
        if (this.volume + delta < 0)
            System.out.println("Не пытайтесь забрать из миски больше, чем есть.");
        else{
            this.volume = this.volume + delta;
            System.out.println("Стало " + this.volume + ".");
        }

    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public String getTypeOfFeed() {
        return typeOfFeed;
    }

    public void setTypeOfFeed(String typeOfFeed) {
        this.typeOfFeed = typeOfFeed;
    }
}
