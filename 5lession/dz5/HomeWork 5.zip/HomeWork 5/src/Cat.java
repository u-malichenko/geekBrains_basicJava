/*
created by Дмитрий Аристов
Класс Cat, дополненный
 */

public class Cat extends Animal {
    protected String name;
    protected int appetite;         // аппетит
    protected boolean satiety;      // сытость
    protected int countOfActivities = 0;    // счётчико активностей (бег, прыжок)
    protected int maxCountOfActivities = 2;    // максимальная активность, после которой кот становится голодным

    public Cat(String species, String name, int appetite) {
        super(species);      // вызов родительского конструктора
        this.name = name;
        maxDistanceRun = 200;
        maxDistanceSwim = 0;
        maxHeightJump = 2;
        this.appetite = appetite;
        this.satiety = false;       // при создании кот голодный
    }


    public void run(double distance) {
        System.out.print(name + " ");
        super.run(distance);
        countOfActivities = countOfActivities + 2;
    }


    public void jump(double height) {
        System.out.print(name + " ");
        super.jump(height);
        countOfActivities = countOfActivities + 1;
    }


    public void swim(double distance) {
        System.out.print(name + " ");
        super.swim(distance);
    }

    public boolean getSatiety() {       // признак сытости
        if (countOfActivities >= maxCountOfActivities) {    // если активность больше максимальной, то кот голодный
            countOfActivities = 0;                          // обнуляем счётчик активности
            satiety = false;
        }
        return satiety;
    }

    public void setSatiety(boolean satiety) {   // установка сытости в нужное "положение"
        this.satiety = satiety;
    }

    public boolean eatFood(int quantityOfFood) {   // едим еду. Передаём количество предложенной еды
        if (!getSatiety()) {                    // проверка сытый или нет
            if (appetite <= quantityOfFood) {    // проверка достаточно ли еды, если да, то
                setSatiety(true);               // сытость true
                countOfActivities = 0;          // обнуляется счётчик активности
                System.out.println(name + " наелся");
                return true;                    // успешно поел
            } else {                            // иначе к еде не притрагиваемся
                System.out.println(name + " не притронулся. Мало еды");
                return false;                   // не поел
            }
        } else {                                // если сытый, то выводим в консоль, что сытый
            System.out.println(name + " сытый");
            return false;                       // не поел
        }
    }

    public void eatFoodFromPlate(Plate plate) {
        if (eatFood(plate.getQuantityOfFood())) { // проверяем, поел ли из миски, если да, то
            plate.empty(appetite);              // опустошаем миску в соответствие с аппетитом
        };

    }


}
