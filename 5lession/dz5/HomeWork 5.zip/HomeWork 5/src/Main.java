/*
created by Дмитрий Аристов
 */

import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);


    public static void main(String[] args) {
        Cat cat1 = new Cat("(домашняя)", "Барсик", 5);
        Cat cat2 = new Cat("(мейнкун)", "Ричард", 15);
        Plate plate1 = new Plate (6);
        Plate bigPlate = new Plate(100);
        Cat[] cats = new Cat[6];
        cats[0] = new Cat("(домашняя)", "Барсик", 5);
        cats[1] = new Cat("(мейнкун)", "Ричард", 15);
        cats[2] = new Cat("(домашняя)", "Мурзик", 4);
        cats[3] = new Cat("(мейнкун)", "Гарольд", 23);
        cats[4] = new Cat("(мейнкун)", "Мозес", 21);
        cats[5] = new Cat("(домашняя)", "Пушок", 6);


        do {
            System.out.print("В 1-й миске " + plate1.getQuantityOfFood() + " единиц еды, влезает " + plate1.getMaxQuantityOfFood() + " единиц. Сколько еды положить в миску? ");
            plate1.fill(scanner.nextInt());
        } while (plate1.getQuantityOfFood() ==0);       // пока не введётся корректное количество

        cat1.eatFoodFromPlate(plate1);                  // кот1 поели из 1-й миски
        cat2.eatFoodFromPlate(plate1);                  // кот2 поел из 1-й миски
        System.out.println(cat1.name + " (сытость: " + cat1.getSatiety() + " )");
        System.out.println(cat2.name + " (сытость: " + cat2.getSatiety() + " )");

        System.out.println("В 1-й миске осталось " + plate1.getQuantityOfFood() + " единиц еды");
        System.out.println();

        do {
            System.out.print("Во 2-й миске " + bigPlate.getQuantityOfFood() + " единиц еды, влезает " + bigPlate.getMaxQuantityOfFood() + " единиц. Сколько еды положить в миску? ");
            bigPlate.fill(scanner.nextInt());
        } while (bigPlate.getQuantityOfFood() ==0);

        for (Cat ct : cats) {                           // для каждого кота из массива котов
            while (bigPlate.getQuantityOfFood() < ct.appetite) {        // сразу проверка и накладывание еды, если нужно
                System.out.print("Для того, чтобы " + ct.name + " поел, не хватает еды (" + (bigPlate.getQuantityOfFood() - ct.appetite) + " ед.) Наполните миску ");
                bigPlate.fill(scanner.nextInt());
                System.out.println("Во 2-й миске " + bigPlate.getQuantityOfFood() + " единиц еды");
            }
            ct.eatFoodFromPlate(bigPlate);              // коты едят из 2-й миски
        }

        for (Cat ct : cats) {                          // вывод состояния сытости котов
            System.out.println(ct.name + " (сытость: " + ct.getSatiety() + " )");
        }

        System.out.println("Во 2-й миске осталось " + bigPlate.getQuantityOfFood() + " единиц еды");
        System.out.println();

        cats[2].jump(1);                        // кот[2] проявляет активность
        cats[2].run(100);

        for (Cat ct : cats) {                          // вывод состояния сытости котов после активности
            System.out.println(ct.name + " (сытость: " + ct.getSatiety() + " )");
        }

    }
}
