/*
created by Дмитрий Аристов
Класс Plate
 */

public class Plate {
    private int maxQuantityOfFood;
    private int quantityOfFood;

    public Plate(int maxQuantityOfFood) {
        this.maxQuantityOfFood = maxQuantityOfFood;
        this.quantityOfFood = 0;
    }

    public int getQuantityOfFood() {        // сколько еды в миски?
        return quantityOfFood;
    }

    public int getMaxQuantityOfFood() {     // вместимость миски?
        return maxQuantityOfFood;
    }

    public void fill(int quantityOfFood) {              // наполнение миски
        if ((quantityOfFood <= (maxQuantityOfFood - this.quantityOfFood)) && quantityOfFood > 0) {      // проверка, влезет ли еда, если да, то
            this.quantityOfFood = this.quantityOfFood + quantityOfFood;         // добавляем еду
        }
    }

    public void empty(int quantityOfFood) {             // опустошение миски
        if (this.quantityOfFood >= quantityOfFood) {     // проверка, в миске достаточно еды, если да, то
            this.quantityOfFood = this.quantityOfFood - quantityOfFood; // опустошаем миску на величину аппетита
        } else {
            this.quantityOfFood = 0;                    // для перспективы (когда коты будут есть из миски, в которой еды меньше,
                                                        // чем их аппетит) опустошаем миску полностью
        }
    }
}
