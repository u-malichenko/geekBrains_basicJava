/*
created by Дмитрий Аристов
Родительски класс
 */

public class Animal {

    protected String species;     // вид
    protected double maxDistanceRun;
    protected double maxDistanceSwim;
    protected double maxHeightJump;

    public Animal(String species) {
        this.species = species;
    }

    public void run(double distance) {
        if (distance < maxDistanceRun) {
            System.out.println(species + " пробежал(а) " + distance + " метров");
        } else {
            System.out.println(species +  " не побежал(а)");
        }
    }

    public void jump(double height) {
        if(height < maxHeightJump) {
            System.out.println(species + " подпрыгнул(а) на высоту " + height + " м");
        } else {
            System.out.println(species + " не прыгнул(а)");
        }
    }

    public void swim(double distance) {
        if(distance < maxDistanceSwim) {
            System.out.println(species + " проплыл(а) " + distance + " метров");
        } else {
            System.out.println(species + " не поплыл(а)");
        }
    }
}
