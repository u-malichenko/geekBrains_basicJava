package Animals;


public class Cat extends Animal {

    protected int urge;

    public Cat() {
        this.runDistance = 200;
        this.hight = 2;
        this.swimDistance = 0;
        this.name = "unNamed";
        this.hungry = true;
    }

    public Cat(String name) {
        this.name = name;
        this.hungry = true;

    }
    public Cat(String name, int urge) {
        this.name = name;
        this.hungry = true;
        this.urge = urge;

    }

    public Cat(int runDistance, int swimDistance, double hight, String name){
        this.runDistance = runDistance;
        this.swimDistance = swimDistance;
        this.hight = hight;
        this.name = name;
    }
    @Override
    public void voice(){

    }
    @Override
    public boolean swim(int distance) {
       System.out.println("коты не умеют плавать!");
       return false;
    }

    @Override
    public void checkHungry(){
        if (hungry){
            System.out.println("Котика "+name+" нужно покормить!");
        } else {
            System.out.println("Котик "+name+" сыт!");
        }
    }
   @Override
    public String toString() {
       String state;
        if (hungry) {
             state = "голоде";
        } else {
             state = "сыт";
        }
        return "Котик "+name +"  "+ state ;
    }
}

