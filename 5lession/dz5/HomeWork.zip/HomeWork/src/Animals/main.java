package Animals;

public class main {


    public static void main(String[] args) {

        Cat catNapoleon = new Cat("Napoleon");
        Cat catFlafy = new Cat("Flafy");

        Bowl bowlofNapoleon = new Bowl("Napoleon");
        Bowl bowlOfFlafy = new Bowl("Flafy");

        if (catNapoleon.hungry == true) {
            catNapoleon.checkHungry();
            catNapoleon.eat(50, bowlofNapoleon);
            bowlofNapoleon.stateMessage();
            catNapoleon.checkHungry();
        }

        if (bowlofNapoleon.checkFullness() < bowlofNapoleon.capacity) {
            bowlofNapoleon.stateMessage();
            bowlofNapoleon.putMealinBowl(1000);
            bowlofNapoleon.putMealinBowl(10);
            bowlofNapoleon.stateMessage();
        }

        catFlafy.checkHungry();
        bowlOfFlafy.stateMessage();

        Bowl bigBowl = new Bowl("Общая");

        Cat[] cats = new Cat[4];
        cats[0] = new Cat("Frady",40);
        cats[1] = new Cat("Flafy",50);
        cats[2] = new Cat("Napoleon",60);
        cats[3] = new Cat("Bigy",30);

        for (Cat cat: cats){
            while (cat.hungry){
                if (bigBowl.fullness>=cat.urge){
                    cat.eat(cat.urge,bigBowl);
                    bigBowl.stateMessage();

                } else {
                    System.out.println("недостаточно еды!");
                    bigBowl.putMealinBowl(cat.urge - bigBowl.fullness);// не будем перекармливать котиков. Ожирение это серьезная проблема!!
                }

            }

        }
        System.out.println("Состояние сытости котов:");
        for (int i=0;i<cats.length;i++){ //выведем условие сытости намеренно в отдельный цикл, добавим @override для toString
            System.out.println(cats[i]);
        }


    }
}
