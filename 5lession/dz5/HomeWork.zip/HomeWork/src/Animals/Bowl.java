package Animals;

public class Bowl implements BowlState {


    int capacity;
    int fullness;
    String nameOfBowl;

    public Bowl(String name) {
        this.nameOfBowl = name;
        this.capacity = 100;
        this.fullness = 100;

    }
    public void stateMessage(){
        System.out.println("Сейчас "+ fullness+" еды в миске " + nameOfBowl);
    }

    public int checkFullness() {

        return fullness;
    }

    public void putMealinBowl(int meal) {
        if (capacity >= meal+fullness){
            fullness += meal;
            System.out.println("Добавили еды "+ meal+" в миску "+nameOfBowl);
        } else {
            System.out.println("Миска " +nameOfBowl+ " слишком мала, для еще "+ meal+ " еды!");
        }

    }
    public boolean eatFromBowl(int meal){
        boolean result;

        if (fullness >= meal) {
            fullness = fullness - meal;
            System.out.println("Из миски "+ nameOfBowl+" съедено "+meal+" еды");
            result = true;
        } else {
            System.out.println("еды в миске слишком мало!");
            result = false;
        }
        return result;
    }
}
