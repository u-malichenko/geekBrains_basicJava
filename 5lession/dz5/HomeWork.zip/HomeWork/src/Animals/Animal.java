package Animals;

public abstract class  Animal {

    protected int runDistance;
    protected double hight;
    protected int swimDistance;
    protected String name;
    protected Boolean hungry;


    public Animal() {

    }
    public abstract void checkHungry();
    public abstract void voice();



    public void eat(int meal, Bowl bowl){
        if(bowl.eatFromBowl(meal)){
            hungry =false;
            System.out.println(name+ " покушал!");
        }

    }


    public boolean run(int distance) {

        boolean result = false;

        if (this.runDistance >= distance) {
            result = true;
        }
        return result;
    }

    public boolean swim(int distance) {
        boolean result = false;

        if (this.swimDistance >= distance) {
            result = true;
        }
        return result;
    }

    public boolean jump(double hight) {
        boolean result = false;

        if (this.hight >= hight) {
            result = true;
        }
        return result;

    }
}
