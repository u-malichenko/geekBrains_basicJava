package Animals;

public interface BowlState {

     void stateMessage();
     int checkFullness();
     void putMealinBowl(int meal) ;
     boolean eatFromBowl(int meal);

}

