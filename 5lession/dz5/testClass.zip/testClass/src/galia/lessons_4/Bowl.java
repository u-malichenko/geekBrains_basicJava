package galia.lessons_4;

public class Bowl {
    //2. Кот должен есть из миски. Создайте такую сущность, которая будет обладать объёмом и едой в ней,
    // а также методами наполнения и получения информации о количестве еды;

    private final int VOLUME = 10;
    private int food;



    public Bowl() {
        this.food = VOLUME;
    }

    public void fillingBowl(){

        this.food = VOLUME;
        System.out.println("Еды недостаточно, поэтому миска наполнена вновь.");
    }

    public int getFood() {
        return this.food;
    }

    public void setFood(int food) {
        this.food = food;
    }
}
