package galia.lessons_4;

public interface Swimable {

     void swim(double value);
}
