package galia.lessons_4;

public interface Jumpable {
     void jump(double value);
}
