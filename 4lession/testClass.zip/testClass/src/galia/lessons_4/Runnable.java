package galia.lessons_4;

public interface Runnable {

     void run(double value);
}
