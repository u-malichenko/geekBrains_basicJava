package malichenko.basicJava.Lession6.Homework;

public class _3CalculateTest {
    public static void main(String[] args) {
        _3CalculatorApp app =new _3CalculatorApp();
    }
}
