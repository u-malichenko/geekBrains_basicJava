package malichenko.basicJava.lession4;

public class SuperCat extends Cat{
    public SuperCat(String _name, double _run, double _jump){
        super("Кот "  + _name);
        this.maxRun = _run;
        this.maxJump = _jump;
    }
}
