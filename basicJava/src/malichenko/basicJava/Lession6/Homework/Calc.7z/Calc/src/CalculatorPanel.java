import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class CalculatorPanel extends JPanel {
    private JButton display;
    private JPanel panel;
    private double result;
    private String lastCommand;
    private boolean start;
    public CalculatorPanel() {
        setLayout(new BorderLayout());

        result = 0;
        lastCommand = "="; // для первого хода должно быть = так как в действтях нужно просто показать
        // потом дейсвие сменять на нажатую кнопку и уже со вторым числом произведут последнее действие
        start=true;

        //добавляем кнопку вверх для текста делаем ее энайбл
        display = new JButton("0");
        display.setEnabled(false);
        add(display, BorderLayout.NORTH); //добавляем на панель и делаем ее вверху

        ActionListener insert = new InsertAction();//два разных актионлисера
        ActionListener command = new CommandAction();

        panel = new JPanel();// Создаем панель с гридлайаут и суем туда кнопки
        panel.setLayout(new GridLayout(4, 4));

        addButton("7", insert); // мктод создания кнопок с передачей типа инсерт или команд
        addButton("8", insert);
        addButton("9", insert);
        addButton("/", command);//два разных актионлисера

        addButton("4", insert);
        addButton("5", insert);
        addButton("6", insert);
        addButton("*", command);

        addButton("1", insert);
        addButton("2", insert);
        addButton("3", insert);
        addButton("-", command);

        addButton("0", insert);
        addButton(".", insert);
        addButton("=", command);
        addButton("+", command);

        add(panel, BorderLayout.CENTER); // добавляем панель с кнопками на панель
    }

    private void addButton(String label, ActionListener listener) {
        JButton button = new JButton(label);
        button.addActionListener(listener);
        panel.add(button);
    }

    private class InsertAction implements ActionListener // для цифер)
    {
        public void actionPerformed(ActionEvent event)
        {
            String input = event.getActionCommand();
            if(start) {
                display.setText("");//емли это первое гажатие то убираем первоначальный 0 или старые данные
                start = false;
            }
            display.setText(display.getText() + input); //добавляем к полю новый символ
        }
    }

    private class CommandAction implements ActionListener // для команд
    {
        public void actionPerformed(ActionEvent event)
        {
            String command = event.getActionCommand();
            if(start) // для первого нажатия
            {
                if(command.equals("-")) // нажат -минус
                {
                    display.setText(command);  // вписать в поле
                    start = false;
                }
                else lastCommand = command; // вписать в команду
            }
            else // если нажатие не первое
            {
                calculate(Double.parseDouble(display.getText())); // запустить метод калькуляте передать число
                lastCommand = command; // вписать в команду
                start=true;  // все снова
            }
        }
    }
    public void calculate(double x)
    {
        if(lastCommand.equals("+")) result += x; // результат +число
        else if(lastCommand.equals("-")) result -= x;
        else if(lastCommand.equals("*")) result *= x;
        else if(lastCommand.equals("/")) result /= x;
        else if(lastCommand.equals("=")) result = x; // тут происходить сболс предыдущего значения результ
        display.setText("" + result);
    }

//    private JButton display;
//    private JPanel panel;
//    private double result;
//    private String lastCommand;
//    private boolean start;
}